<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>This is first time for PHP</h2>
    <?PHP
    echo "Hello world!";
    ?>
    
</body>
</html>