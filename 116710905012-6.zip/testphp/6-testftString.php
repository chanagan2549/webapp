<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function which function calls</title>
</head>
<body>
    <h2>Writing PHP Function which function calls</h2>
<?php
        function sayHello() {
       echo "Hello Com sci <br />";
        }
        $function_holder ="sayHello";
        $function_holder();
        sayHello();
    
    ?>
</body>
</html>
 